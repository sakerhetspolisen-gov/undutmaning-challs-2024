import * as mapdata from './mapdata.json' assert { type: 'json' }
import geckos from '@geckos.io/server'
import process from 'node:process'
import {GameMsg, PlayerMsg, MapMsg} from './protoc/gamemsg.js'

let ticker = 0
let multiplay = true
const mm = GameMsg.create({multiplay: multiplay, mapobjects: mapdata.default})
console.log("created map message")



const players = {}
const tstart = new Date().getTime()
let idcntr = 1
const port = 3001
const io = geckos({
  iceServers: process.env.NODE_ENV === 'production' ? iceServers : [],
  portRange: {
    min: process.env.PORT_RANGE_MIN ? parseInt(process.env.PORT_RANGE_MIN) : 10000,
    max: process.env.PORT_RANGE_MAX ? parseInt(process.env.PORT_RANGE_MAX) : 10007,
  }
})
process.on('SIGUSR1', () => {
  console.log("Switching off multiplay.")
  multiplay = false
  mm.multiplay = false
  io.emit('multiplay', multiplay)
})
process.on('SIGUSR2', () => {
  console.log("Switching on multiplay.")
  multiplay = true
  io.emit('multiplay', multiplay)
  mm.multiplay = false
})
io.onConnection((channel) => {
  console.log(`connect: ${channel.id} (${Object.keys(players).length + 1} players)`)
  // send init message
  let p_id = idcntr++
  channel.emit('id', p_id)
  channel.raw.emit(GameMsg.toBinary(mm))

  channel.onDisconnect(() => {
    if(players[channel.id])
      channel.broadcast.emit('disconnect', players[channel.id].id)
    delete players[channel.id]
    console.log(`disconnect: ${channel.id}`)
  })

  channel.onRaw((b) => {
    try {
      const msg = GameMsg.fromBinary(new Uint8Array(b))
      if(msg.players.length == 1 && (players[channel.id] == null || msg.players[0].id == players[channel.id].id)) {
        players[channel.id] = msg.players[0]
        if(multiplay)
          channel.raw.broadcast.emit(GameMsg.toBinary(GameMsg.create({multiplay: multiplay, tick: ticker++, players: Object.values(players)})))
      }
    } catch(e) {
      console.log("Malformed message.", e)
    }
  })
})


io.listen(port, () => {
  console.log(`App listening on http://localhost:${port}/`)
})

