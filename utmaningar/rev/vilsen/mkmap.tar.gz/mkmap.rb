#!/usr/bin/env ruby
#
require 'bdf'
require 'optparse'
require 'json'

options = {}
options[:font] = "./font/ter-u12b.bdf"
options[:fuzz] = 0.0
options[:mdensity] = 0.0
options[:tdensity] = 0.0
options[:preview] = false
op = OptionParser.new do |opts|
  opts.banner = "Usage: mkmap.rb [options] STRING"

  opts.on("-v", "--[no-]verbose", "Run verbosely") do |v|
    options[:verbose] = v
  end
  opts.on("-h", "--help", "Prints this help") do
    puts opts
    exit
  end
  opts.on("-sSIZE", "--size SIZE", "Size of map (area SIZE**2) (required)") do |s|
    options[:size] = s.to_i
  end
  opts.on("-fFONT", "--font FONT", "Font file (bdf format)") do |f|
    options[:font] = f
  end
  opts.on("-zFUZZ", "--fuzz FUZZ", "Fuzz coordinates") do |f|
    options[:fuzz] = f.to_f
  end
  opts.on("-mMDENSITY", "--mushrooms MDENSITY", "Density of additional mushrooms.") do |f|
    options[:mdensity] = f.to_f
  end
  opts.on("-tTDENSITY", "--trees TDENSITY", "Density of trees.") do |f|
    options[:tdensity] = f.to_f
  end
  opts.on("-p", "--preview", "Print preview") do
    options[:preview] = true
  end
end
op.parse!
if(ARGV.size == 1 && options[:size])
  str = ARGV.first
  ff = options[:fuzz]
  size = options[:size]
else
  print("Flag string and size required, see mkmap.rb -h for help.\n")
  exit
end
# create flag
font   = BDF::Font.from_file(options[:font])
points = BDF::Renderer.render(str, :font => font).to_a
scale = size/points[0].size*1.0
yscale = scale
# preview
if(options[:preview])
   points.each{|r| p r.join("").gsub("0", " ").gsub("1", "x")}
   exit
end
# flag coordinates
mpoints = []
0.upto(points.size-1) do |y|
  0.upto(points[0].size-1) do |x|
    if(points[y][x] > 0)
      mpoints.push([(x+(ff*rand))*scale-0.5*size, (-y+(ff*rand)+0.5)*yscale])
      STDERR.print("#{mpoints[-1].join(" ")}\n")
    end
  end
end
# extra mushrooms
if(options[:mdensity])
  n = (options[:mdensity]*options[:size]**2).to_i
  STDERR.print("# Adding #{n} mushrooms.\n")
  n.times do
    mpoints.push([rand*size - 0.5*size, rand*size-0.5*size])
  end
end

# trees
tpoints = []
if(options[:tdensity])
  n = (options[:tdensity]*options[:size]**2).to_i
  STDERR.print("# Adding #{n} trees.\n")
  n.times do
    tpoints.push([rand*size-0.5*size, rand*size-0.5*size])
  end
end

data = []
mpoints.each do |mp|
  data.push({ objtype: 1,
            x: mp.first.round(2),
            z: mp.last.round(2),
            rot: (2*Math::PI*rand).round(2),
            scale: (0.5 + rand).round(2)})
end
tpoints.each do |tp|
  data.push({ objtype: 2,
            x: tp.first.round(2),
            z: tp.last.round(2),
            y: (-2*rand).round(2),
            rot: (2*Math::PI*rand).round(2),
            scale: (0.2 + 2*rand).round(2)})
end
print data.to_json
